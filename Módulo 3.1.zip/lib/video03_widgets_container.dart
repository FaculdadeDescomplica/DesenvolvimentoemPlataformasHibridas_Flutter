// A importação deste pacote nós da acesso aos widgets dart
// bem como aos Widgets Material Theme
import 'package:flutter/material.dart';
// o método main() é o ponto de entrada da sua aplicação
void main() {
  // chamando este método você executa sua aplicação
  runApp(
    // Este widget é o suporte para outros Widgets. Vamos apenas usar o argumento color
    Container(
      color: Colors.blue, // <-- Podemos mudar a propriedade Colors
    ),
  );
}