import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Aplicativo'),
        ),
        body: const Center(
          child: Text(
            'Olá, mundo!',
            style: TextStyle(fontSize: 50, color: Color.fromARGB(255, 196, 6, 6)),
          ),
        ),
      ),
    ),
  );
}