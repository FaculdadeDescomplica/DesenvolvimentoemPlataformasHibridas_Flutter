import 'package:flutter/material.dart';

void main() {
  // O método runApp() inicializa o layout da app
  // MyApp() é um widget que será a raiz da nossa aplicação
  runApp(const MyApp());
}

// o widget raiz
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // O método build reconstrói a árvore de widegts se houver mudanças
  // e permite o hot reload
  @override
  Widget build(BuildContext context) {
    // Agora ao ínves de um Container estamos usando o widget MaterialApp
    // o qual é configurado para dar à nossa app um tema Material
    return MaterialApp(
      // O widget Scaffold define o layout da home
      home: Scaffold(
        // Vamos passar um widget AppBar widget para a propriedade appBar do Scaffold
        appBar: AppBar(
          // A prop. AppBar usa um widget Text widget para a sua prop. title
          title: const Text('Aprendendo sobre Widgets'),
        ),
        // A prop. body do widget Scaffold widget é o conteúdo principal da tela
        // Ao inves de usar diretamente a widget nós vamos definir a widgter em outro
        // método para facilitar o tratamento
        body: myWidget1(),
      ),
    );
  }
}

// Aqui é onde vamos tratar a widget Text
Widget myWidget1() {
  return const Text(
    'Olá, Mundo!',
  );
}

// Aqui é onde vamos tratar a widget Text
Widget myWidget2() {
  return const Text(
    'Olá, Mundo!',
    style: TextStyle(
      fontSize: 30.0,
    ),
  );
}

// Aqui é onde vamos tratar a widget Text
Widget myWidget3() {
  return const Padding(
    // Define o padding usando o widget EdgeInsets.
    // O valor 16.0 significa 16 pixels logicos. Esta é
    // uma resolução independente.
    padding: EdgeInsets.all(16.0),
    // Quando envolver um widget com outro widget,
    // você usa a propriedade child do widget pai
    child: Text(
      "Olá,Mundo Flutter!",
    ),
  );
}

// TextField aceita entrada de texto do usuário.
Widget myWidget4() {
  return const TextField(
    decoration: InputDecoration(
        border: InputBorder.none, hintText: 'Escreva alguma coisa aqui...'),
  );
}

// ListView exibe uma lista de itens
Widget myWidget5() {
  return ListView.builder(
    padding: const EdgeInsets.all(16.0),
    // espacamento das linhas
    itemExtent: 20.0,
    // fornece uma lista infinita
    itemBuilder: (BuildContext context, int index) {
      return Text('Linha $index');
    },
  );
}

Widget myWidget6() {
  return TextButton(
    style: ButtonStyle(
      foregroundColor: MaterialStateProperty.all<Color>(Colors.red),
    ),
    onPressed: () {},
    child: const Text('Meu Botão'),
  );
}

Widget myWidget7() {
  return TextButton(
    style: ButtonStyle(
      foregroundColor: MaterialStateProperty.all<Color>(Colors.red),
    ),
    onPressed: () {},
    child: const Text('Meu Botão'),
  );
}

Widget myWidget8() {
  // ignore: prefer_typing_uninitialized_variables
  var raisedButtonStyle;
  return ElevatedButton(
    style: raisedButtonStyle,
    onPressed: () {},
    child: const Text('Botão'),
  );
}
