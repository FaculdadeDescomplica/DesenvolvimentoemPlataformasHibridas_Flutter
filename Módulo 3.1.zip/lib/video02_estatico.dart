// A importação deste pacote da acesso aos widgets dart
// bem como aos Widgets Material Theme
import 'package:flutter/material.dart';
// o método main() é o ponto de entrada da sua aplicação
void main() {
  // Chamando esse método você executa sua aplicação
  return runApp(
    const MaterialApp(
    home: StatelessWidgetExemplo('Módulo 03: Aula 02 - MaterialApp')
  ));
}
class StatelessWidgetExemplo extends StatelessWidget {
  final String _appBarTitle;
  const StatelessWidgetExemplo(this._appBarTitle, {super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_appBarTitle)
      ),
      body: const Center(
        child: Text('Prof. Dr. Eduardo Mendes')
      )
    );
  }
}