/// https://www.darttutorial.org/

/// Método main é o ponto de partida de um programa Dart
main() {
  /// Chama a função print que irá exibir a mensagem na tela
  print("Olá Mundo!");
}

/// Cria a função saudacao
/// String saudacao(String mensagem) {
  /// Retorna o valor 
  ///return '$mensagem';
///}

///void main() {
  /// Chama a função saudacao, passando os paramentros
  ///print(saudacao('Olá mundo, seja bem vindos ao Dart!'));
///}
